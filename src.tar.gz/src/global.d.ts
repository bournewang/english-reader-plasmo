interface Window {
    SpeechSDK: any;
}
// interface Window {
//     SpeechSDK: typeof import("microsoft-cognitiveservices-speech-sdk");
// }
declare var process: {
    env: {
        REACT_APP_API_URL: string;
    };
};  

declare const chrome: any;
